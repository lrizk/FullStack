

// alert("Hola mundo");

// let producto = "nombre del producto";

// let disponible;

// disponible = true;

// disponible = "no hay producto";

// disponible = 564;

// let camiseta = "rosa",
// pantalon = "falda",
// zapatos = "botas";
// DE ESTA FORMA SE PUEDEN USAR MULTIPLES VARIABLES QUE SEAN IGUAL, RESUMIENDO USANDO (,)


let camiseta = "rosa";
let pantalon = "falda";
let zapatos = "botas";

zapatos = "negro";

console.log("comentario camiseta:",camiseta);

console.log("comentario pantalon:",pantalon);

console.log("comentario zapatos:",zapatos);

// let 1variable = "numero"

const constante = "valor constante"

console.log("comentario constante:", constante);

const global=0;

console.log("comentario global",global);

let computadora="windows";
console.log("esta computadora tiene un sistema operativo:",computadora);